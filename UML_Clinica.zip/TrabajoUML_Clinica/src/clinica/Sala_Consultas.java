package clinica;

public class Sala_Consultas {

	
	private int num_Sala;
	private String equipamiento;
	private String doctor_asignado;
	private String ubicacion;
	private boolean ocupada;
	private int capacidad_paciente;
	
	
	public Sala_Consultas() {

	}

	
	

	public int getNum_Sala() {
		return num_Sala;
	}


	public void setNum_Sala(int num_Sala) {
		this.num_Sala = num_Sala;
	}


	public String getEquipamiento() {
		return equipamiento;
	}


	public void setEquipamiento(String equipamiento) {
		this.equipamiento = equipamiento;
	}


	public String getDoctor_asignado() {
		return doctor_asignado;
	}


	public void setDoctor_asignado(String doctor_asignado) {
		this.doctor_asignado = doctor_asignado;
	}


	public String getUbicacion() {
		return ubicacion;
	}


	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}


	public boolean isOcupada() {
		return ocupada;
	}


	public void setOcupada(boolean ocupada) {
		this.ocupada = ocupada;
	}


	public int getCapacidad_paciente() {
		return capacidad_paciente;
	}


	public void setCapacidad_paciente(int capacidad_paciente) {
		this.capacidad_paciente = capacidad_paciente;
	}
	
	
	
}
