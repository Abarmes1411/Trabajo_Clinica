package clinica;

public class Administrador extends Persona {

	
	private Farmacia farmacia;

	public Administrador() {

	}

	
	
	
	public Farmacia getFarmacia() {
		return farmacia;
	}

	public void setFarmacia(Farmacia farmacia) {
		this.farmacia = farmacia;
	}
	
	
}
