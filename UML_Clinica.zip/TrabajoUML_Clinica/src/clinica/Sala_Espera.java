package clinica;

public class Sala_Espera {

	
	private int pacientes_total;
	private int cap_max;
	private String equipamiento;
	
	
	
	
	public int getPacientes_total() {
		return pacientes_total;
	}
	
	public void setPacientes_total(int pacientes_total) {
		this.pacientes_total = pacientes_total;
	}
	
	public int getCap_max() {
		return cap_max;
	}
	
	public void setCap_max(int cap_max) {
		this.cap_max = cap_max;
	}
	
	public String getEquipamiento() {
		return equipamiento;
	}
	
	public void setEquipamiento(String equipamiento) {
		this.equipamiento = equipamiento;
	}
	
	
	
}
