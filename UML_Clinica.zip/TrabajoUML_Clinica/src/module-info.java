/**
 * 
 */
/**
 * 
 */
module TrabajoUML_Clinica {
}