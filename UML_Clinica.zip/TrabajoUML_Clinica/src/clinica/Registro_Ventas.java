package clinica;

public class Registro_Ventas {

	private String nombre_paciente;
	private String medicamento_dispensado;
	private float dosis;
	private int cantidad;
	private float precio;
	
	
	public Registro_Ventas() {
		
	}


	
	
	public String getNombre_paciente() {
		return nombre_paciente;
	}


	public void setNombre_paciente(String nombre_paciente) {
		this.nombre_paciente = nombre_paciente;
	}


	public String getMedicamento_dispensado() {
		return medicamento_dispensado;
	}


	public void setMedicamento_dispensado(String medicamento_dispensado) {
		this.medicamento_dispensado = medicamento_dispensado;
	}


	public float getDosis() {
		return dosis;
	}


	public void setDosis(float dosis) {
		this.dosis = dosis;
	}


	public int getCantidad() {
		return cantidad;
	}


	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}


	public float getPrecio() {
		return precio;
	}


	public void setPrecio(float precio) {
		this.precio = precio;
	}
	
	
	
}
