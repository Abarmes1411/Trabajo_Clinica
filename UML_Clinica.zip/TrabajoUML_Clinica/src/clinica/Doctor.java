package clinica;

import java.util.Date;
import java.util.List;

public class Doctor extends Persona {

	private String especialidad;
	private Date horario;
	private List<Paciente> paciente;
	private List<Sala_Consultas> sala_consultas;
	
	
	public Doctor() {
		
	}


	
	
	
	public List<Sala_Consultas> getSala_consultas() {
		return sala_consultas;
	}


	public void setSala_consultas(List<Sala_Consultas> sala_consultas) {
		this.sala_consultas = sala_consultas;
	}





	public List<Paciente> getPaciente() {
		return paciente;
	}



	public void setPaciente(List<Paciente> paciente) {
		this.paciente = paciente;
	}





	public String getEspecialidad() {
		return especialidad;
	}


	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}


	public Date getHorario() {
		return horario;
	}


	public void setHorario(Date horario) {
		this.horario = horario;
	}
	
	
}
