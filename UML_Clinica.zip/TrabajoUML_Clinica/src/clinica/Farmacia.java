package clinica;

import java.util.List;

public class Farmacia {

	private List<Registro_Ventas> registro_ventas;

	
	
	public Farmacia(List<Registro_Ventas> registro_ventas) {
		this.registro_ventas = registro_ventas;
	}

	public List<Registro_Ventas> getRegistro_ventas() {
		return registro_ventas;
	}

	public void setRegistro_ventas(List<Registro_Ventas> registro_ventas) {
		this.registro_ventas = registro_ventas;
	}
	
	
}
