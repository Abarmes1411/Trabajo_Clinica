package clinica;

import java.util.Date;

public class Paciente extends Persona {

	private boolean seguro_Medico;
	private Date fecha_nac;
	private String genero;
	private Historial_Medico hist_med;
	private Sala_Espera sala_espera;
	
	public Paciente() {
	}

	

	
	
	public Paciente(Historial_Medico hist_med, Sala_Espera sala_espera) {
		
		this.hist_med = hist_med;
		this.sala_espera = sala_espera;
	}





	public Sala_Espera getSala_espera() {
		return sala_espera;
	}

	public void setSala_espera(Sala_Espera sala_espera) {
		this.sala_espera = sala_espera;
	}



	public Historial_Medico getHist_med() {
		return hist_med;
	}



	public void setHist_med(Historial_Medico hist_med) {
		this.hist_med = hist_med;
	}



	public boolean isSeguro_Medico() {
		return seguro_Medico;
	}


	public void setSeguro_Medico(boolean seguro_Medico) {
		this.seguro_Medico = seguro_Medico;
	}


	public Date getFecha_nac() {
		return fecha_nac;
	}


	public void setFecha_nac(Date fecha_nac) {
		this.fecha_nac = fecha_nac;
	}


	public String getGenero() {
		return genero;
	}


	public void setGenero(String genero) {
		this.genero = genero;
	}
	
	
	
}
