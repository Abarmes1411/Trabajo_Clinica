package clinica;



public class Historial_Medico {

	private String diagnosticos;
	private String tratamientos;
	private String medicamentos_recetados;
	
	public Historial_Medico() {
	}

	
	
	public String getDiagnosticos() {
		return diagnosticos;
	}

	public void setDiagnosticos(String diagnosticos) {
		this.diagnosticos = diagnosticos;
	}

	public String getTratamientos() {
		return tratamientos;
	}

	public void setTratamientos(String tratamientos) {
		this.tratamientos = tratamientos;
	}

	public String getMedicamentos_recetados() {
		return medicamentos_recetados;
	}

	public void setMedicamentos_recetados(String medicamentos_recetados) {
		this.medicamentos_recetados = medicamentos_recetados;
	}
	
	
}
